%This routine does a radial scan. Start it in the center of the magnet.

%% Setup and initialization
clear all;
addpath(genpath('functions'));  %add folders to the path
addpath(genpath('data'));

global g; %GPIB instrument, Sypris gauss probe
global s; %Serial instrument, Velmex VXM stage controller
g = SyprisInitialize(); %initializes communication with Sypris gauss probe
s = VXMinitialize(); %initializes communiction with VXM stage controller

global FieldAndPositionDATA; FieldAndPositionDATA = []; %vector that saves all data
global stepsPerMillimeter; stepsPerMillimeter = 400; %lead screw pitch is 1mm/revolution, stepper motor does 400 steps/revolution
global filenameDescription; %gets appended to the file name
global scanComment;


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% PROMPT TO GET MAGNET PARAMETERS %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
prompt = {'Enter radius of scan.','Enter number of radial points to collect','Enter the delay time between steps in seconds.','Enter comments about this run, e.g. the magnet type and current.','Enter short string appended to the filename to make it unique (no dashes, spaces or periods).'}';
dlgTitle = 'Radial scan parameters';
num_lines = 1;
defaultAns = {'40','120','1','#### pole tip, ## Amps,## inch radius','_WeakFocusingRadialScan1'};
inputParams = inputdlg(prompt,dlgTitle,num_lines,defaultAns);

scanRadius = str2num(cell2mat(inputParams(1)));
numSteps = str2num(cell2mat(inputParams(2)));
delay = str2num(cell2mat(inputParams(3)));
scanComment = cell2mat(inputParams(4));
filenameDescription = cell2mat(inputParams(5));

fprintf(s,'Q')
uiwait(msgbox('VXM is in manual mode. Move the probe to the magnet center.'))

%% Do the scan!
radialScan(scanRadius,numSteps,delay); 

%% Save data.
    dateString = datestr(now,'yymmdd');
    filePath = pwd;
    if exist([filePath,dateString]) == 0
        mkdir(strcat(filePath,'\data\',dateString,'\'));
    end
    save(strcat(filePath,'\data\',dateString,'\',dateString,filenameDescription));

%% Basic analysis
basicRadialscanAnalysis(scanRadius,numSteps) %do analysis on the run and display results

%% Clean up the objects to finish
cleanup(s); cleanup(g);
