%This routine performs a linear scan using the Velmex stage and Sypris
%gauss probe. 
%Written by Heidi for Tim's cyclotron class.


%% Setup and initialization
clear all;
addpath(genpath('functions'));  %add folders to the path
addpath(genpath('data'));

global g; %GPIB instrument, Sypris gauss probe
global s; %Serial instrument, Velmex VXM stage controller
g = SyprisInitialize(); %initializes communication with Sypris gauss probe
s = VXMinitialize(); %initializes communiction with VXM stage controller

global FieldAndPositionDATA; FieldAndPositionDATA = []; %vector that saves all data
global stepsPerMillimeter; stepsPerMillimeter = 400; %lead screw pitch is 1mm/revolution, stepper motor does 400 steps/revolution
global filenameDescription; %gets appended to the file name
global scanComment;
%judging me for using a million global variables? yeah, deal with it.

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PROMPT TO GET SCAN PARAMETERS %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
prompt = {'Enter travel distance in mm','Enter step size in mm.','Choose direction: enter x for right/left or y for in/out.','Enter the delay time between steps in seconds.','Enter comments about this run, e.g. the pole tip type and current.','Enter short string appended to the filename to make it unique (no dashes, spaces or periods).'};
dlgTitle = 'Linear scan parameters';
num_lines = 1;
defaultAns = {'300','10','x','1','#### pole tip, ## Amps','_WeakFocusingScan1'};
inputParams = inputdlg(prompt,dlgTitle,num_lines,defaultAns);

distance = str2num(cell2mat(inputParams(1)));
increment = str2num(cell2mat(inputParams(2)));
direction = cell2mat(inputParams(3));
delay = str2num(cell2mat(inputParams(4)));
scanComment = cell2mat(inputParams(5));
filenameDescription = cell2mat(inputParams(6));

fprintf(s,'Q'); %put VXM into manual mode
uiwait(msgbox('VXM is in manual mode. Move the probe to its raster scan starting position using the Jog buttons on the VXM.'));
fprintf(s,'N'); %set VXM position registers to 0,0

%% Do the scan.
LinearScan_withPause(distance,direction,increment,delay);

%% Save data.
    dateString = datestr(now,'yymmdd');
    filePath = pwd;
    if exist([filePath,dateString]) == 0
        mkdir(strcat(filePath,'\data\',dateString,'\'));
    end
save(strcat(filePath,'\data\',dateString,'\',dateString,filenameDescription));


%% Clean up to finish
cleanup(s);cleanup(g);