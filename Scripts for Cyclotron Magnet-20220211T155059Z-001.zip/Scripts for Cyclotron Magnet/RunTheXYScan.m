%This routine performs a 2D raster scan.
%Written by Heidi for Tim's cyclotron class.

%% Setup and initialization
clear all;
addpath(genpath('functions'));  %add folders to the path
addpath(genpath('data'));

global g; %GPIB instrument, Sypris gauss probe
global s; %Serial instrument, Velmex VXM stage controller
g = SyprisInitialize(); %initializes communication with Lakeshore
s = VXMinitialize(); %initializes communiction with VXM stage controller

global datacounter; datacounter = 0;
global FieldAndPositionDATA; FieldAndPositionDATA = []; %vector that saves all data
global inchTostep; inchTostep = 8000; %the VXM stage has 16000 steps in an inch
global scanParameters; scanParameters = []; %holds info about the scan which will be useful in analysis later
global scanComment; 
global filenameDescription; %gets appended to the file name


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PROMPT TO GET MAGNET PARAMETERS %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
prompt = {'Enter Y distance in inches','Enter X distance (across the bore) in inches.','Enter step increment in inches.','Enter the delay time between steps in seconds.','Enter comments about this run, e.g. the magnet type and current.','Enter short string appended to the filename.'};
dlgTitle = 'XY Scan parameters';
num_lines = 1;
defaultAns = {'.2','.2','.1','1','linear scan','lin'};
inputParams = inputdlg(prompt,dlgTitle,num_lines,defaultAns);

Xdim = str2num(cell2mat(inputParams(1)));
Ydim = str2num(cell2mat(inputParams(2)));
increment = str2num(cell2mat(inputParams(3)));
delay = str2num(cell2mat(inputParams(4)));
scanComment = cell2mat(inputParams(5));
filenameDescription = cell2mat(inputParams(6));

typeOfScan = 'linear 2D';
scanParameters = [typeOfScan,Xdim,Ydim,increment,delay];

fprintf(s,'Q');
uiwait(msgbox('VXM is in manual mode. Move the probe to its raster scan starting position. Set the angle marker to 270.'));

%% Do the scan.
XYscan(Xdim,Ydim,increment,delay);

%% Save any remaining data points that weren't auto-saved by RecordData routine
dateString = datestr(now,'yymmdd');
save(strcat('C:\Users\Strange\Documents\UMD\Courses\Cyclotron Design\Magnet lab\Magnet Lab MATLAB\data\',date,'/',dateString,filenameDescription),'scanParameters','FieldAndPositionDATA');

%% Basic Analysis
basicXYscanAnalysis(Xdim,Ydim,increment)

%% Clean up to finish
cleanup(s);cleanup(g);