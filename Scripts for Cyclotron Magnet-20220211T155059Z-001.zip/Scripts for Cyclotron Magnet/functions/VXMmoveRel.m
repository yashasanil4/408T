function y = VXMmoveRel(relPosition)
%This function moves the stage to the relative position [x,y] given in the
%argument. Input is in millimeters.
%If the input is 0, commands for that dimension are skipped, because the 
%VXM interprets that as "go to home".

    global s; global stepsPerMillimeter;

    xmove = relPosition(1)*stepsPerMillimeter;
    ymove = relPosition(2)*stepsPerMillimeter;

    %clear the serial buffer by reading it
    if s.bytesAvailable ~= 0
        fread(s,s.bytesAvailable);
    end
        pause(0.2);

    if xmove ~= 0
        cmd = strcat('F,C,I1M',num2str(xmove),',R');
        fprintf(s,cmd); 

        while s.bytesAvailable ==0
        %do nothing and wait until the ^ character is returned when the stage
        %stops moving
        pause(0.2);
        end

        fread(s,s.bytesAvailable);
    end

    if ymove ~= 0
        cmd = strcat('F,C,I2M',num2str(ymove),',R');
        fprintf(s,cmd);
        while s.bytesAvailable ==0
        %do nothing and wait until the ^ character is returned when the stage
        %stops moving
        pause(0.2);
        end
        fread(s,s.bytesAvailable)
    end


end