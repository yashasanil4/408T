function y=LinearScan(distance,direction,increment,delay)

if direction == 'x'
    for i = 1:distance/increment
        VXMmoveRel([increment,0])
        pause(delay)
        RecordData();
    end
end

if direction == 'y'    
    for i = 1:distance/increment
        VXMmoveRel([0,increment])
        pause(delay)                             
        RecordData();
    end
end

end
