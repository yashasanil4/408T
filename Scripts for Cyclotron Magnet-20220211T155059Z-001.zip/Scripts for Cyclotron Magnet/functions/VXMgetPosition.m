function y = VXMgetPosition()
%Returns a vector with [x,y,z,t] positions of the stage IN STEP UNITS

global s;

xposmeas = query(s,'X');
xposmeas = str2num(regexprep(xposmeas,'[^1234567890]','')); %clean up the output

yposmeas = query(s,'Y');
yposmeas = str2num(regexprep(yposmeas,'[^1234567890]',''));

y = [xposmeas,yposmeas];
end
