function y = VXMmoveAbs(absPosition)
%This function moves the stage to the absolute position [x,y,z] given in the
%argument. Input is in STEPS.

global s

xmove = absPosition(1);
ymove = absPosition(2);
zmove = absPosition(3);

%clear the serial buffer by reading it
if s.bytesAvailable ~= 0
    fread(s,s.bytesAvailable);
end

cmd = strcat('F,C,IA1M',num2str(xmove),',R');
fprintf(s,cmd); 

while s.bytesAvailable ==0
   %do nothing and wait until the ^ character is returned when the stage
   %stops moving
end
fread(s,s.bytesAvailable);

cmd = strcat('F,C,IA2M',num2str(ymove),',R');
fprintf(s,cmd); 

while s.bytesAvailable ==0
   %do nothing and wait until the ^ character is returned when the stage
   %stops moving
end
fread(s,s.bytesAvailable);

cmd = strcat('F,C,IA3M',num2str(zmove),',R');
fprintf(s,cmd); 

while s.bytesAvailable ==0
   %do nothing and wait until the ^ character is returned when the stage
   %stops moving
end
fread(s,s.bytesAvailable);

end