function y=LinearScan(distance,direction,increment,delay)
%use this for collecting Gauss probe data manually. No gauss probe data is
%collected. There's a prompt after every step. 

if direction == 'x'
    for i = 1:distance/increment
        VXMmoveRel([increment,0])
        pause(delay)
        uiwait(msgbox('Continue?'));

    end
end

if direction == 'y'    
    for i = 1:distance/increment
        VXMmoveRel([0,increment])
        pause(delay) 
        uiwait(msgbox('Continue?'));
    end
end

end
