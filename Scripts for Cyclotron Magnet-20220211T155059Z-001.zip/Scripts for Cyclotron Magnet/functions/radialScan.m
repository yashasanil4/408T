function y = radialScan(radius,numSteps,delay) 
%Radial scan starting and ending at the magnet center.

VXMmoveRel([radius,0]); %move to the side
xlast = 0;
ylast = 0;

for theta = 0:2*pi/numSteps:2*pi
    [x,y]=pol2cart(theta,radius)
    deltax = x - xlast
    deltay = y - ylast;
    if theta ~=0    
        VXMmoveRel([deltax,deltay]);
    end
    pause(delay);
    RecordData();
    xlast = x;
    ylast = y;
end
VXMmoveRel([-radius,0]);


