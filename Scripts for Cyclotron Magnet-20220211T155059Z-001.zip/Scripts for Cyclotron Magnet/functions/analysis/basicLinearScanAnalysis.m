function y = basicXYscanAnalysis(direction);

    global FieldAndPositionDATA; global scanParameters; global commentTosave; global filenameDescription;global stepsPerMillimeter;

    %extract components from data vectors
    xposition = FieldAndPositionDATA(:,1);
    yposition = FieldAndPositionDATA(:,2);
    Bfield = FieldAndPositionDATA(:,3);

    figure()
    if direction == 'x'
        plot(xposition,Bfield,'*')
        ylabel(['x (mm)']);
    else 
        plot(yposition,Bfield,'*');
        ylabel(['y (mm)']);
    end
        title(['Linear Scan' scanComment]);
        ylabel(['Magnetic field strength (G)']);

end