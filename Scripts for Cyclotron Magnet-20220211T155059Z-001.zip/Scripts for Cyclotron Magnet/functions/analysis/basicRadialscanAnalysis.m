function y = basicRadialscanAnalysis(radius,numSteps);

    global FieldAndPositionDATA; global scanParameters; global commentTosave; global filenameDescription;global stepsPerMillimeter;

    %extract components from data vectors
    xposition = FieldAndPositionDATA(:,1);
    yposition = FieldAndPositionDATA(:,2);
    Bfield = FieldAndPositionDATA(:,3);

    theta = 0:2*pi/numSteps:2*pi;

    figure;
    plot(theta,Bfield,'r'); hold on
    title(['B_\theta' commentTosave])
    xlabel(['Angle in degrees'])
    ylabel(['Magnetic field strength (G)']);

    

end