function y = basicXYscanAnalysis(Xdim,Ydim,increment);

global FieldAndPositionDATA; global scanParameters; global commentTosave; global filenameDescription;global stepsPerMillimeter;

%extract components from data vectors
Bfield = FieldAndPositionDATA(:,7)';
xposition = FieldAndPositionDATA(:,1)';
yposition = FieldAndPositionDATA(:,2)';
zposition = FieldAndPositionDATA(:,3)';
thetaPosition = FieldAndPositionDATA(:,4);

% xposition = xposition * inchToStep;
% yposition = yposition * inchToStep;
% zposition = zposition * inchToStep;
% 


xsize = length(0:increment:Xdim)
ysize = length(0:increment:Ydim)
Xp = increment * [1:ysize];
Yp = increment * [1:xsize];
% plot ([1:length(yfield)],yfield)
Xf = reshape(xfield,[xsize,ysize]);
Yf = reshape(yfield,[xsize,ysize]);
Zf = reshape(zfield,[xsize,ysize]);

figure()
mesh(Xp,Yp,Xf)
title(['XY scan, Bx of probe ' date]);
xlabel(['x (cm) (longitudinal axis)']);
ylabel(['y (cm) (transverse axis)']);
zlabel(['Bx of probe (G)']);

figure()
mesh(Xp,Yp,Yf)
title(['XY scan, By of probe ' date]);
xlabel(['x (cm) (longitudinal axis)']);
ylabel(['y (cm) (transverse axis)']);
zlabel(['By of probe(G)']);

figure()
mesh(Xp,Yp,Zf)
title(['XY scan, Bz of probe ' date]);
xlabel(['x (cm) (longitudinal axis)']);
ylabel(['y (cm) (transverse axis)']);
zlabel(['Bz of probe (G)']);

end