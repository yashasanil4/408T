function y = XYscan(Xdim,Ydim,increment,delay)
% This function performs a raster scan. It only records data
% while moving in one direction, because the stage has some back and 
% forth play. At the end, it moves back to its starting position.

global inchTostep;

Xdim = Xdim * inchTostep;
Ydim = Ydim * inchTostep;
increment = increment * inchTostep;

for j=0:increment:Ydim
    for i=0:increment:Xdim
        %RecordData(); 
        if i~= Xdim
            VXMmoveRel([increment,0,0]);  
            pause(delay);
        end
    end
    if j ~= Ydim
        VXMmoveRel([0,increment,0]); %move over in y
    end
    VXMmoveRel([-Xdim,0,0]); %move back in x
end

%move back to orig point
VXMmoveRel([0,-Ydim,0]);

end