function y=RecordData()
% This function records data to a .mat file with the following structure:
% [x position | y position | B field]

    global s; global g;
    global FieldAndPositionDATA; global scanParameters; global commentTosave; 
    global filenameDescription;global stepsPerMillimeter;

%% Read out field from Sypris
    Bfield = str2num(query(g, 'MEAS:FLUX?'))
    
% Get x and y position w.r.t. the zero point set at the beginning of scan
    currentPosition = VXMgetPosition();
    currentPosition = 1/stepsPerMillimeter * currentPosition;
 
%% Append position and field data to global variable
    FieldAndPositionDATA = [FieldAndPositionDATA;currentPosition Bfield];  
    
end