function y = SyprisInitialize()
%if unsure of whichport instrument is connected to, do a scan in MATLAB's
%Instrument Control toolbox (and you actually have to click "scan").

obj2 = instrfind('Type', 'serial', 'Port', 'COM7', 'Tag', '');

% Create the serial port object if it does not exist
% otherwise use the object that was found.
if isempty(obj2)
    obj2 = serial('COM7');
else
    fclose(obj2);
    obj2 = obj2(1);
end
set(obj2, 'Terminator', {'LF','LF'}); %there is some confusion over the terminator

% Connect to instrument object, obj1.
fopen(obj2);

y=obj2;

end