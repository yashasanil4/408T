function y=cleanup(x)
fclose(x);
% Clean up all objects.
delete(x);
end
