function y = VXMinitialize()
obj1 = instrfind('Type', 'serial', 'Port', 'COM7', 'Tag', '');

% Create the serial port object if it does not exist
% otherwise use the object that was found.
if isempty(obj1)
    obj1 = serial('COM7');
else
    fclose(obj1);
    obj1 = obj1(1);
end
set(obj1, 'Terminator', {'CR','CR'}); %there is some confusion over the terminator

% Connect to instrument object, obj1.
fopen(obj1);

y=obj1;

end