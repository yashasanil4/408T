function y = VXMmoveRelDiagonal(relPosition)
%move diagonally as best as it goes
%don't send it x and y together because the stage can't move them in a
%coordinated way

global s

xmove = relPosition(1)
ymove = relPosition(2)
zmove = relPosition(3)

%clear the serial buffer by reading it
if s.bytesAvailable ~= 0
    fread(s,s.bytesAvailable);
end
    pause(0.2);

if xmove ~= 0 && ymove ~= 0 && zmove ~=0
    cmd = strcat('F,C,(I3M',num2str(zmove),',I2M',num2str(ymove),',I1M',num2str(xmove),',),R');
    fprintf(s,cmd); 
    
    while s.bytesAvailable ==0
    %do nothing and wait until the ^ character is returned when the stage
    %stops moving
    pause(0.2);
    end
    fread(s,s.bytesAvailable);
    
elseif zmove ~= 0 && ymove ~= 0
    cmd = strcat('F,C,(I3M',num2str(zmove),',I2M',num2str(ymove),',),R');
    fprintf(s,cmd);
    while s.bytesAvailable ==0
    %do nothing and wait until the ^ character is returned when the stage
    %stops moving
    pause(0.2);
    end
    fread(s,s.bytesAvailable)
elseif zmove ~=0 && xmove ~=0
    cmd = strcat('F,C,(I3M',num2str(zmove),',I1M',num2str(xmove),',),R');
    fprintf(s,cmd); 
    
    while s.bytesAvailable ==0
    %do nothing and wait until the ^ character is returned when the stage
    %stops moving   
    pause(0.2);
    end
    
    fread(s,s.bytesAvailable);
end

end