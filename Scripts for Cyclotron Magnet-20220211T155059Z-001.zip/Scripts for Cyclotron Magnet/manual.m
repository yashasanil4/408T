% quickly put the VXM into manual control

s = VXMinitialize(); %initializes communiction with VXM stage controller
fprintf(s,'Q')