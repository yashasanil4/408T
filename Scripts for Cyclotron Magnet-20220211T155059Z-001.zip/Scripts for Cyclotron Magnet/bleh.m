

myComPort = serial('COM3');
fopen(myComPort);
% now disconnect the device
delete(myComPort)
clear myComPort
% now connect the device again, the following will now be successful:
myComPort = serial('COM3');
fopen(myComPort);